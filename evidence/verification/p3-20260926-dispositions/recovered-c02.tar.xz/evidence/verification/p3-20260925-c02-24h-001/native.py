"""Native preflight and detached one-shot launch for Issue #39; no retries."""
import ctypes
import json
import os
from pathlib import Path
import platform
import runpy
import subprocess
import sys
import time
from ctypes import wintypes as w

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / 'src'))
sys.dont_write_bytecode = True
from uppaal_mcp import verification_manager as m
VERIFYTA = Path(r'C:\Program Files (x86)\UPPAAL-5.0.0\bin\verifyta.exe')
SOURCE = 'ac2d6d31682df7957cabc58ff58d4267dcd56f08'


def preflight():
    class Memory(ctypes.Structure):
        _fields_ = [('length', w.DWORD), ('load', w.DWORD)] + [(n, ctypes.c_ulonglong) for n in
            ('total', 'available', 'page_total', 'page_available', 'virtual_total', 'virtual_available', 'extended')]
    memory = Memory(); memory.length = ctypes.sizeof(memory)
    assert ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory))
    command = ['powershell.exe', '-NoProfile', '-Command',
        'Get-CimInstance Win32_Process | Where-Object { $_.Name -eq "verifyta.exe" -or ($_.Name -like "python*" -and ($_.CommandLine -like "*verification_manager*" -or $_.CommandLine -like "*native.py*worker*")) } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json']
    processes = subprocess.run(command, capture_output=True, text=True, check=True)
    hardware = subprocess.run(['powershell.exe', '-NoProfile', '-Command',
        'Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors | ConvertTo-Json'], capture_output=True, text=True, check=True)
    version = subprocess.run([str(VERIFYTA), '--version'], cwd=VERIFYTA.parent, capture_output=True, timeout=20)
    stamp = str(time.time_ns())
    (HERE / ('version-' + stamp + '.stdout.txt')).write_bytes(version.stdout)
    (HERE / ('version-' + stamp + '.stderr.txt')).write_bytes(version.stderr)
    record = {'timestamp': m.now(), 'source_commit': SOURCE, 'platform': platform.platform(),
        'python': sys.version, 'python_executable': sys.executable, 'cpu': json.loads(hardware.stdout),
        'memory_bytes': {n: getattr(memory, n) for n, _ in Memory._fields_},
        'processes': json.loads(processes.stdout) if processes.stdout.strip() else [],
        'version_exit_code': version.returncode, 'tool_version': version.stdout.decode(errors='replace'),
        'verifyta_hash': m.digest(VERIFYTA), 'timeout_seconds': 86400, 'memory_mib': 8192,
        'memory_ready': memory.available >= (8192 + 2048) * 1024**2,
        'memory_policy': 'Require 8192 MiB available plus 2048 MiB headroom before launch'}
    m.save(HERE / ('preflight-' + stamp + '.json'), record)
    print(json.dumps(record, indent=2))


def launch(kind):
    destination = HERE / (kind + '-launch.json')
    if destination.exists():
        raise RuntimeError('Already launched; inspect existing run, never retry automatically')
    command = [sys.executable, '-B', str(Path(__file__).resolve()), 'worker', kind]
    with (HERE / (kind + '-manager.stdout.txt')).open('xb') as out, (HERE / (kind + '-manager.stderr.txt')).open('xb') as err:
        proc = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
            creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP, close_fds=True)
    m.save(destination, {'pid': proc.pid, 'command': command, 'cwd': str(ROOT), 'timestamp': m.now(),
        'flags': 'DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP', 'source_commit': SOURCE})
    print(proc.pid)


def worker(kind):
    time.sleep(5)  # parent tool call must return before the smoke begins
    if kind == 'smoke':
        sys.argv = [str(ROOT/'evidence/manager/20260924/native-smoke.py'), str(HERE/'smoke'), str(VERIFYTA), SOURCE]
        runpy.run_path(sys.argv[0], run_name='__main__')
        code = 0
    elif kind == 'c02':
        code = m.main(['start', str(HERE/'queue')])
    else:
        raise ValueError(kind)
    m.save(HERE/(kind+'-exit.json'), {'exit_code': code, 'finished_at': m.now()})
    raise SystemExit(code)


if __name__ == '__main__':
    if os.name != 'nt':
        raise RuntimeError('Use Windows Python')
    action = sys.argv[1]
    if action == 'preflight': preflight()
    elif action == 'launch': launch(sys.argv[2])
    elif action == 'worker': worker(sys.argv[2])
    else: raise ValueError(action)
