# Latest attempt: memory_limit, C02 not verified

Attempt `001-29c3409912fe43029fa925b140dbf40a` ran with the fixed manager
for 8324.030 seconds (2h 18m 44s), stopping at the configured sampled
8192 MiB threshold. Peak working set 8590032896 bytes; CPU 8273.859375s.
No verdict/trace or manager error. Exact provenance and successful integrity
audit are in memory-limit-report.json; raw attempt/session artifacts retained.
No automatic retry. Previous failure evidence below is historical and preserved.

# Terminal result: error, C02 not verified

Attempt `001-e23a763bdb5e494992898e93344e604d` ended at 2026-09-24T21:47:34.158987+00:00 after 743.363 seconds.
Manager failed replacing status.json with WinError 5 (access denied), then
terminated its verifier child in exception cleanup. Peak working set
1265565696 bytes; CPU 720.796875 seconds. No verdict or trace.
All attempt hashes, model/query hashes and tool version audited successfully.
See terminal-report.json and queue/attempts/. No automatic retry.
The process causing access denial is unknown; no evidence of a resource limit.
Fixing the manager belongs to its tooling scope, not this evidence-only branch.

The following preparation record is historical; its NOT STARTED status is superseded.

# C02 24-hour preparation — Issue #39

Owner/runner vadimnbkg. Run ID p3-20260925-c02-24h-001.
Branch codex/vadimnbkg/39-c02-24h-20260925; base read at
ac2d6d31682df7957cabc58ff58d4267dcd56f08 (merged PR #52).
Independent PR reviews/comments absent at inspection: unreviewed/experimental
manager use, no independent acceptance claimed. Scope evidence/verification/**.

Full frozen baseline reviewer-r1-gate1-20260923, accepted Gate 1/P1/P2.
Model SHA256 592678ed678ce8f70cf278f542e48bd2bb739969b53a962423d3e63f91e3e1e2.
C02.q SHA256 cec919bc6e2d960160976799d3d52ff4f25eea9f136f7b0231c02cec13f162db.
Only C02 is authorized: 86400 seconds, 8192 MiB sampled working-set threshold,
BFS -o 0 -t 0. No automatic retries. Frozen inputs and previous evidence unchanged.

Current status: C02 NOT STARTED. Windows available memory after user closed apps
was initially 4441120768 bytes (4235.4 MiB); latest 7630413824 bytes
(7276.9 MiB) at 2026-09-24T21:26:09Z, still below 8192 MiB plus OS headroom.
Latest native preflight JSON has actual hardware/version/process inspection.
No license/proxy/power settings changed. Native version output is retained.

Detached software smoke completed after launch tool returned, using Windows
DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP, redirected stdin/stdout/stderr,
and five-second worker delay. Existing manager native-smoke.py produced both
expected verdicts and measured memory/time; continuation skipped both attempts.
All attempt hashes audited. This is SOFTWARE SMOKE, not C02 verification.
Exact smoke run IDs, hashes, tool_version and success statuses are in
smoke/smoke.json and smoke/queue/attempts/*/result.json.

native.py is a one-shot launcher; it refuses a second launch of the same kind.
It runs the unchanged manager. preflight records memory and existing workers.
Queue is initialized at ./queue, phase=ready, worker_active=false. Hashes checked;
exact limits 86400 seconds and 8589934592 bytes, options -o 0 -t 0.
Before launching C02, recheck RAM, processes and clean committed provenance.
Then save a durable checkpoint before running native.py launch c02.
Do not use launch c02 until these checks are complete.

Durable transport: full Git bundle on the owner's local Windows drive at
C:\Users\musta\Desktop\pySources\mcp_uppaal\evidence\verification\p3-20260925-c02-24h-001.bundle.
SSH fetch was unavailable (host-key verification), HTTPS read works.
No P3/C02 closure or acceptance by producer.

Validation: Linux installed suite 193 tests OK (93.791s); Windows manager
12 passed / 1 POSIX-only skipped (11.948s). Initial Linux attempt without
installation had 2 failures and 2 errors (missing CLI and mcp); retained in
linux-tests.log, corrected by isolated /tmp/c02-20260925-venv installation.
Commands and outputs: install.log, linux-tests-installed.log, windows-tests.log.
Code/docs/query whitespace check clean. Raw version logs retain verifier trailing
spaces/CRLF and therefore full diff --check reports whitespace (not edited).
All changed paths remain inside this unique evidence package.

HTTPS push failed: no local credentials (terminal prompts disabled). SSH failed
host-key verification. Full history bundle is the durable handoff, not a PR.
Next step: user frees more RAM; repeat native.py preflight, then one launch only
when resources suffice. No C02 attempt, PID, telemetry or verdict exists yet.
Control commands: commands.md. Queue inputs, baseline parameters and instance
vector: provenance.json and queue/queue.json. The completed smoke is distinct.
