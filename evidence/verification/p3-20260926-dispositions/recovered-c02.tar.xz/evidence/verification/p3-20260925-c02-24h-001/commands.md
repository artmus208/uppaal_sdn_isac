# PowerShell commands for this exact machine

C02 has not started; pause/resume/stop require a live worker.
`continue` restarts an incomplete C02 from scratch; run only after an explicit retry decision.

```powershell
$env:PYTHONPATH = 'C:\Users\musta\Desktop\pySources\mcp_uppaal\evidence\verification\worktrees\p3-20260925-c02-24h-001\src'
& 'C:\Users\musta\AppData\Local\Programs\Python\Python313\python.exe' -B -m uppaal_mcp.verification_manager status 'C:\Users\musta\Desktop\pySources\mcp_uppaal\evidence\verification\worktrees\p3-20260925-c02-24h-001\evidence\verification\p3-20260925-c02-24h-001\queue'
& 'C:\Users\musta\AppData\Local\Programs\Python\Python313\python.exe' -B -m uppaal_mcp.verification_manager pause 'C:\Users\musta\Desktop\pySources\mcp_uppaal\evidence\verification\worktrees\p3-20260925-c02-24h-001\evidence\verification\p3-20260925-c02-24h-001\queue'
& 'C:\Users\musta\AppData\Local\Programs\Python\Python313\python.exe' -B -m uppaal_mcp.verification_manager resume 'C:\Users\musta\Desktop\pySources\mcp_uppaal\evidence\verification\worktrees\p3-20260925-c02-24h-001\evidence\verification\p3-20260925-c02-24h-001\queue'
& 'C:\Users\musta\AppData\Local\Programs\Python\Python313\python.exe' -B -m uppaal_mcp.verification_manager stop 'C:\Users\musta\Desktop\pySources\mcp_uppaal\evidence\verification\worktrees\p3-20260925-c02-24h-001\evidence\verification\p3-20260925-c02-24h-001\queue'
& 'C:\Users\musta\AppData\Local\Programs\Python\Python313\python.exe' -B -m uppaal_mcp.verification_manager continue 'C:\Users\musta\Desktop\pySources\mcp_uppaal\evidence\verification\worktrees\p3-20260925-c02-24h-001\evidence\verification\p3-20260925-c02-24h-001\queue'
```

pause is between formulas: it does not pause the sole C02 search.
resume controls a live queue; stop terminates the search.
No C02 dispatcher PID exists until launch. Queue status is ready.
