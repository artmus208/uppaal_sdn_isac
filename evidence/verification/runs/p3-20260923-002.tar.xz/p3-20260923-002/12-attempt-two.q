E<> sdn_attempt_total == 2
