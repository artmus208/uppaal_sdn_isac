E<> mac_queue_q > 0
