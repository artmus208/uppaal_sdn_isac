E<> sdn_attempt_primary == 1
