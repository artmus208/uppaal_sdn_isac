E<> sdn_attempt_rollback == 1
