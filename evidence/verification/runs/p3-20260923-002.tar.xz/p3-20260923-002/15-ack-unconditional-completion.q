mac_obs_ack_active --> !mac_obs_ack_active
