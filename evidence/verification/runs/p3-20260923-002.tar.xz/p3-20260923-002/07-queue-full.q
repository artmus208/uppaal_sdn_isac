E<> mac_queue_q == mac_queue_K && !mac_queue_overflow_seen
