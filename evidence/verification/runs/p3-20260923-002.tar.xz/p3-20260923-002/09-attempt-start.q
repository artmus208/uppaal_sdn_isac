E<> sdn_attempt_active
