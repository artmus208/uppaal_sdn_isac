E<> mac_queue_overflow_seen
