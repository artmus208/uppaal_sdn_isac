A[] not deadlock
