A[] !sdn_attempt_bad
