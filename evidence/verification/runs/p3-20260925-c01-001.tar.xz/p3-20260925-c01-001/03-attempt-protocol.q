A[] !sdn_attempt_protocol_error
