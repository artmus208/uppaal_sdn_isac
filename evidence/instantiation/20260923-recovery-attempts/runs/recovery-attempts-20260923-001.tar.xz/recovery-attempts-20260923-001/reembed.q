A[] !sdn_attempt_bad
A[] !sdn_attempt_protocol_error
E<> fx_done == 1 && !fx_failed && sdn_attempt_primary == 1 && sdn_attempt_rollback == 0 && sdn_attempt_total == 1 && !sdn_attempt_active
