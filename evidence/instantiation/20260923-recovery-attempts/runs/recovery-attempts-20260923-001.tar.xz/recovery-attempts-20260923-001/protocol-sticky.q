A[] !sdn_attempt_bad
A[] !sdn_attempt_protocol_error
E<> driver.S2 && (sdn_attempt_total == 0 && sdn_attempt_active)
