E<> true
