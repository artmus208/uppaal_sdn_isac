A[] !sdn_attempt_bad
A[] !sdn_attempt_protocol_error
E<> driver.S3 && (sdn_attempt_primary == 2 && sdn_attempt_total == 2)
