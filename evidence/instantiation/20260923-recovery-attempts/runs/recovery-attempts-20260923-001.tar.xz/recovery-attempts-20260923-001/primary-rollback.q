A[] !sdn_attempt_bad
A[] !sdn_attempt_protocol_error
E<> sdn_attempt_primary == 1 && sdn_attempt_rollback == 1 && sdn_attempt_total == 2
