A[] !sdn_attempt_bad
A[] !sdn_attempt_protocol_error
E<> fx_done == 2 && sdn_attempt_primary == 1 && sdn_attempt_total == 1 && !sdn_attempt_active
