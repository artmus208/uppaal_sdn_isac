A[] !sdn_attempt_bad
A[] !sdn_attempt_protocol_error
E<> driver.S1 && (sdn_attempt_total == 1)
