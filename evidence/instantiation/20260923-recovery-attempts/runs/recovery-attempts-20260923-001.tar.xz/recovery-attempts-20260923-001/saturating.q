A[] !sdn_attempt_bad
A[] !sdn_attempt_protocol_error
E<> driver.S11 && (sdn_attempt_primary == 2 && sdn_attempt_rollback == 2 && sdn_attempt_total == 3)
