A[] !sdn_attempt_bad
A[] !sdn_attempt_protocol_error
E<> driver.S5 && (sdn_attempt_total == 0 && sdn_attempt_active)
