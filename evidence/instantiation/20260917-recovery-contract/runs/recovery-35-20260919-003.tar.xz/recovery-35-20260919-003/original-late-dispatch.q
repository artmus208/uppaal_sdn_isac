E<> fx_started == 1 && rec.FailureDetected
E<> rec.FailureDetected && fx_age == 31
E<> fx_done == 1 && fx_age == 31
