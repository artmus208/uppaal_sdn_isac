A[] !(sdn_obs_rec_late || (sdn_obs_rec_active && sdn_c_obs_rec > 30))
A[] !sdn_obs_rec_protocol_error
A[] not deadlock
E<> rec.RecoveryFailed && !sdn_failure_report_sent
E<> rec.RecoveryFailed && sdn_failure_report_sent && !sdn_recovery_report_pending
