E<> fx_started == 1 && rec.FailureDetected
E<> fx_done == 0 && sdn_obs_rec_active && sdn_c_obs_rec > 30
A[] !(sdn_obs_rec_late || (sdn_obs_rec_active && sdn_c_obs_rec > 30))
