A[] !(sdn_obs_rec_late || (sdn_obs_rec_active && sdn_c_obs_rec > 30))
A[] !sdn_obs_rec_protocol_error
A[] not deadlock
E<> fx_started == 1 && rec.FailureDetected
E<> fx_done == 1 && !fx_failed && fx_age == 20
E<> fx_done == 1 && fx_age == 30
E<> rec.RecoveryFailed && sdn_recovery_report_pending && !sdn_failure_report_sent
