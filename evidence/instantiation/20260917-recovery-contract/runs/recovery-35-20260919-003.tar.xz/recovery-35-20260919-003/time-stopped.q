E<> fx_started == 1 && rec.FailureDetected
A[] fx_age == 0
A[] fx_done == 0
A[] !(sdn_obs_rec_late || (sdn_obs_rec_active && sdn_c_obs_rec > 30))
A[] not deadlock
