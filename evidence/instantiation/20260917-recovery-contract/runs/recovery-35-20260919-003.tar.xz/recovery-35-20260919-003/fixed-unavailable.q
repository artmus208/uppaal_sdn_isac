A[] !(sdn_obs_rec_late || (sdn_obs_rec_active && sdn_c_obs_rec > 30))
A[] !sdn_obs_rec_protocol_error
A[] not deadlock
E<> fx_started == 1 && rec.FailureDetected
E<> rec.RecoveryFailed && fx_age == 20 && sdn_recovery_failure_kind == 1
A[] (fx_started == 1 && fx_age > 20) imply fx_done == 1
