E<> fx_started == 1 && rec.FailureDetected
E<> fx_done == 1 && !fx_failed && fx_age == 20
E<> obs.Violation && fx_done == 1 && !fx_failed
