E<> fx_started == 1 && rec.FailureDetected
E<> fx_done == 1 && sdn_obs_rec_late && !sdn_obs_rec_active
E<> fx_started == 2 && fx_done == 1 && sdn_obs_rec_late && sdn_obs_rec_active && fx_since_end == 0 && obs.Idle
A[] !(sdn_obs_rec_late || (sdn_obs_rec_active && sdn_c_obs_rec > 30))
