A[] !(sdn_obs_rec_late || (sdn_obs_rec_active && sdn_c_obs_rec > 30))
A[] !sdn_obs_rec_protocol_error
A[] not deadlock
E<> fx_started == 1 && rec.FailureDetected
E<> rec.Rollback && fx_age == 5
E<> fx_done == 1 && !fx_failed && fx_age == 15
E<> sdn_recovery_failure_kind == 2 && fx_age == 15
