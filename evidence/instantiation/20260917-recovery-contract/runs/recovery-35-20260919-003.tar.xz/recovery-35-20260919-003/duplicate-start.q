E<> sdn_obs_rec_protocol_error && sdn_c_obs_rec == 5
A[] fx_started == 1 imply sdn_c_obs_rec == fx_age
