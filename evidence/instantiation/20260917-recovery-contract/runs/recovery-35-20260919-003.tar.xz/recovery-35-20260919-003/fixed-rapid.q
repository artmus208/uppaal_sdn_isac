A[] !(sdn_obs_rec_late || (sdn_obs_rec_active && sdn_c_obs_rec > 30))
A[] !sdn_obs_rec_protocol_error
A[] not deadlock
E<> fx_started == 2 && fx_done == 2 && fx_first == 0 && obs.Idle
E<> fx_started == 2 && fx_done == 1 && fx_since_end == 0
