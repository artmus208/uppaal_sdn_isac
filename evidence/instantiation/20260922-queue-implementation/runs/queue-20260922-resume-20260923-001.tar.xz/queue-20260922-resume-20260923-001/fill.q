A[] !mac_queue_overflow_seen
E<> mac_queue_overflow_seen
E<> mac_queue_q == 4 && !mac_queue_overflow_seen
E<> mac_queue_overflow_seen && bus_time == 25
A[] (bus_time < 25 imply !mac_queue_overflow_seen)
A[] (mac_queue_overflow_seen imply mac_queue_q == 5)
A[] ((mac_queue_q == 0 imply mac_queueClass == mac_Q_EMPTY) && (mac_queue_q == 1 imply mac_queueClass == mac_Q_LOW) && (mac_queue_q == 2 imply mac_queueClass == mac_Q_MED) && (mac_queue_q == 3 imply mac_queueClass == mac_Q_HIGH) && (mac_queue_q >= 4 imply mac_queueClass == mac_Q_CRIT))
