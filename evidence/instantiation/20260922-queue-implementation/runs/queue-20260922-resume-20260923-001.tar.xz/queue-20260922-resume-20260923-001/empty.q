A[] !mac_queue_overflow_seen
A[] mac_queue_q == 0
