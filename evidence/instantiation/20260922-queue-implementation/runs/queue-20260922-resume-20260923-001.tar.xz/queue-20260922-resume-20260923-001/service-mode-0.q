A[] !mac_queue_overflow_seen
E<> mac_queue_q == 0
E<> mac_queue_q == 4 && bus_time >= 15
