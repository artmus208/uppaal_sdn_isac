A[] mac_queue_overflow_seen && mac_queue_q == 5
E<> bus_time >= 15
