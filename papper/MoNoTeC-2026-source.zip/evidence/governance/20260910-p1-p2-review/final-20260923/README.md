# Итоговое ревью P1/P2 — пакет решения от 2026-09-23

Статус: **рекомендовано принять в указанной ниже области; окончательное решение
пользователя/reviewer ещё не записано**. Это результат существующего #28, без
новых задач. Автор пакета участвовал в реализации и не выдаёт собственное
заключение за независимое approval. Gate 1 этим документом не принят.

Проверяемая база `read`: `932f35b98fc1ab4564d59069f34266248f64c558`.
Разрешённые изменения: только этот подкаталог. Код, manifests, исторические
артефакты и рукопись не изменяются.

## Предлагаемое решение

Принять P1 (#15, V01–V05) и P2 (#17/#19, R01/R02/R05/R06) как описание,
обоснование и реализацию **одной конечной абстрактной конфигурации**. Принятие
не означает эмпирическую калибровку, доказательство свойств C01/C02 или
корректность всех исторических observers. Полные проверки свойств относятся
к P3 после Gate 1; отрицательный результат должен сохраняться с контрпримером,
а не заменяться изменением области задним числом.

| Пункт | Основание и итоговая область приёмки |
|---|---|
| V01 | Сохраняется принятое методологическое описание validation; не утверждается выполненная внешняя экспериментальная валидация. |
| V02 | Принимаются явно перечисленные абстрактные предположения и ограничения одной конфигурации. |
| V03 | Принимается полный учёт констант и договорённостей о времени: исходная инвентаризация 43 констант и 14 интеграционных параметров, последующие контракты и перечисленные ниже ограничения. Новые queue/attempt параметры записаны в parameters.json. Универсальная истинность timing-запросов не заявляется. |
| V04 | Принимается методика сопоставления с внешним симулятором; адаптер и эксперимент не выдаются за выполненные. |
| V05 | Принимается воспроизводимый абстрактный набор параметров; физическая шкала, калибровка и переносимость на произвольную сеть не заявляются. |
| R01/R02 | Принимаются scope, instance vector, композиция и интерфейсный контракт P2 с последующими принятыми исправлениями. |
| R05 | Принимается анализ scheduler и его границ; согласование ACK не приравнивается к обслуживанию очереди. |
| R06 | Принимается анализ конечных классов и ограничений абстракции scheduler: 51 840 сочетаний только его входов не являются размером полного пространства состояний. Clock zones и peers учитываются отдельно; scalability и concrete-to-abstract soundness не доказаны. |

Предыдущая частичная приёмка P1:
https://github.com/artmus208/uppaal_sdn_isac/issues/15#issuecomment-5678926378.
Последующие решения по V03:
https://github.com/artmus208/uppaal_sdn_isac/issues/15#issuecomment-5740905172 и
https://github.com/artmus208/uppaal_sdn_isac/issues/15#issuecomment-5740922787.
Настоящее предложение завершает их разбор, а не переоткрывает уже принятые пункты.

## Точная конфигурация

50 процессов: 20 core, 8 boundary и 22 observers. Одна агрегированная serving
BS, одно устройство/UAV, один link, target, controller и service session.
Реализованная интеграция сохраняет явные boundary assumptions, mailbox/coalescing
и недетерминизм. Успех сервиса из доставки ACK не следует.
Не моделируются масштабируемая сеть, явные пакеты или отдельная destination
cell для handover. APP Crit/Agg остаются placeholders без переходов.

`inputs.json` фиксирует SHA-256 модели, генератора, полного candidate query
set, выбранного query set и исходных документов. `parameters.json` содержит
весь набор исходных констант и интеграционных значений. Время — абстрактные
единицы без физической калибровки.

Поле `instance_vector` сохраняет исторический статус proposal исходного файла
для точного provenance. Актуальность реализации определяется проверяемым
commit и текущими metadata, включая queue/attempt overlays; историческая
метка не является новым решением о статусе. `explicit_packet_queues=0`
совместимо с абстрактной occupancy queue: пакетных объектов не добавлено.

Очередь #43/#44: K=4, L=1, M=2, H=4; service-before-arrival, optional service
только в COMM/JOINT. ACK не удаляет работу. K+1 — поглощающее свидетельство
переполнения, sticky overflow сохраняется.

Attempts #45/#46: максимум primary=1, rollback=1, total=2 на эпизод.
Счётчики насыщаются на 2/2/3 для сохранения нарушения; это не разрешённые
лимиты. Старт — фактический приём failure в A_REC, счёт — фактические send
requests, конец — локальный результат. Duplicate start не очищает нарушение.
Счётчики не управляют guards, invariants или synchronization.

## Окончательная disposition ограничений

| Область | Решение для принимаемого scope |
|---|---|
| PHY D_meas=5 против T_meas+J=6 | Известное расхождение сохранено. Нет гарантии report-by-5; глобальный deadlock остаётся обязательным предметом P3. |
| PHY latest-trigger, MAC stages, SDN Monitor/Evaluate | Принимаются явные границы и reset/coalescing semantics из contracts/triage. Общий end-to-end deadline из локальных clocks не выводится. |
| MAC ACK | Принято исправление #31; граница отсчёта send-to-ACK/timeout, ApplySchedule вне этого интервала. |
| Остальные timing observers | Остаются в композиции; соответствующие queries диагностические без принимаемого timing claim. Исключение query не доказывает пассивность observer и не устраняет его влияние на глобальный deadlock. |
| SDN rule/control waits | Сохранены известные пробелы total-response guarantee и пересекающиеся guards. Недетерминизм не заменяется предположением о детерминизме по именам locations. |
| Recovery | Приняты локальные outcomes и границы 20/10 из #35/#38, затем recorder #45/#46. Гарантии восстановления сервиса нет. |
| Admission #36 | Уже отложено; sdn-08/app-02 и соответствующие deadline claims не принимаются. Функциональная admission-логика остаётся. |
| PHY input mapper/APP placeholders | Принимается конечный абстрактный input domain. Эмпирический mapper и отсутствующее поведение placeholders не заявляются. |
| Queue | Реализация и диапазоны приняты; отсутствие overflow полной композиции пока не установлено. |
| Attempts | Реализация recorder принята; соблюдение limits полной композиции пока не установлено. |

## Контракт последующей проверки

`selected-queries.q` содержит 15 явно перечисленных обязательств и диагностик.
`query-disposition.json` даёт disposition каждому запросу текущего candidate
pack; сам generator и его pack этим ревью не меняются.

C01: глобальное отсутствие deadlock, отсутствие queue overflow и превышения
attempt limits. Отдельно проверяется отсутствие protocol error recorder.
C02 ограничен исправленным MAC send-to-ACK/timeout интервалом: elapsed safety
вместе с корректной записью начала и отсутствием reset активного интервала
даёт bounded completion на **time-divergent executions**. Это не безусловное
утверждение termination на Zeno executions. Leads-to сохраняется отдельной
диагностикой, включая возможный отрицательный результат.

Проверки достижимости нужны для невакуозности. Достижимость Idle сама по себе
не подтверждает успешный ACK: для этого нужен trace фактического matching
ACK-перехода WaitPHYAck -> Idle. Timeout отмечается отдельно. Witnesses начала,
primary/rollback/two attempts, непустой/полной очереди не заменяют safety.
Все запросы выполняются на точной полной композиции; результаты reduced
harness нельзя переносить на неё. Сбой, timeout или отсутствие witness
отражаются явно, а не считаются положительной проверкой.

## Evidence и воспроизводимость

Принятые implementation PRs: #44 и #46; предшествующие исправления #31 и #38.
Сохранённые run manifests:

- `evidence/instantiation/20260922-queue-implementation/run.json`,
  run_id `queue-20260922-resume-20260923-001`;
- `evidence/instantiation/20260923-recovery-attempts/run.json`,
  run_id `recovery-attempts-20260923-001`.

Их results-index/composition и архивы определяют status, model_hash,
query_hash, tool_version и область каждого прежнего результата. В частности,
engine-load query полной XML в #46 не является проверкой C01/C02. Настоящее
ревью не запускает UPPAAL и не добавляет verification claims.

Воспроизведение статической сверки из корня checkout с установленным проектом:

```bash
python -B evidence/governance/20260910-p1-p2-review/final-20260923/build.py --check
python -B evidence/instantiation/20260922-queue-implementation/audit.py
python -B evidence/instantiation/20260923-recovery-attempts/audit.py
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -v
python -c "from uppaal_mcp.server import build_mcp; print(type(build_mcp()).__name__)"
```

`build.py` сравнивает входы с Git base, регенерирует metadata и сверяет
модель/query/generator/parameters/vector с сохранённым #46 run. Проверка имён
переменных selected queries не является UPPAAL parsing/type checking.
Фактические результаты команд сохранены в `checks.txt`. Статическая сверка,
оба archive audits, coordination check и FastMCP construction прошли.
Локальный полный suite: 178 tests, один stdio startup timeout внутри sandbox.
Повтор всего startup module вне sandbox: 6 tests OK, включая упавший тест;
исходный failure сохранён. Это согласуется с ограничением окружения, но
полный локальный прогон не обозначается как безошибочный.

## Следующий шаг решения

Reviewer/пользователь принимает или отклоняет **именно этот ограниченный
scope** P1/P2. После принятия решение записывается в существующие #15/#17/#19.
Затем существующий Gate 1 требует отдельной записи integrator в GitHub с base
commit, hashes, parameters, instance vector и точной tool version. Сейчас
baseline остаётся candidate; этот пакет не меняет manifest и не открывает
новых задач.
